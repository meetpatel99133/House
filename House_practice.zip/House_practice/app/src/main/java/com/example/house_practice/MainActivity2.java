package com.example.house_practice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView deatils;
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        //show = findViewById(R.id.housename);
       // show.setText(MainActivity.membrName);
        deatils = findViewById(R.id.moredeatils);
        img = findViewById(R.id.img);
        deatils.setText(MainActivity.deatils);
        int  imgid = getResources().getIdentifier(MainActivity.image,"drawable",getPackageName());
        img.setImageResource(imgid);

    }
}