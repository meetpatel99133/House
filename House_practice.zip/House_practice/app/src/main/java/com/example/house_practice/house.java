package com.example.house_practice;

import android.service.autofill.SaveRequest;

public class house {
    private String  hosenno;
    private  String houseAddress;
    private  String price;
    private String description;
    private  String imgname;

    public house(String hosenno, String houseAddress, String price, String description, String imgname) {
        this.hosenno = hosenno;
        this.houseAddress = houseAddress;
        this.price = price;
        this.description = description;
        this.imgname = imgname;
    }

    public String getHosenno() {
        return hosenno;
    }

    public String getHouseAddress() {
        return houseAddress;
    }

    public String getPrice() {
        return price;
    }

    public String getDescription() {
        return description;
    }

    public String getImgname() {
        return imgname;
    }

    public void setHosenno(String hosenno) {
        this.hosenno = hosenno;
    }

    public void setHouseAddress(String houseAddress) {
        this.houseAddress = houseAddress;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setImgname(String imgname) {
        this.imgname = imgname;
    }
}
