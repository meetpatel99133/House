package com.example.house_practice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener,View.OnClickListener {
    Spinner sp;
    ImageView img;
    TextView price;
    Button btn;
    ArrayList<house> home  = new ArrayList<house>();
    ArrayList<String> address  = new ArrayList<>();
    //public  static  String membrName = "";
    public  static  String image = "";
    public  static  String deatils = "";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sp = findViewById(R.id.spinner);
        img = findViewById(R.id.imageView);
        price = findViewById(R.id.price);
        btn = findViewById(R.id.deatils);
        btn.setOnClickListener(this);
        filldata();
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line,address);
        sp.setAdapter(aa);
        sp.setOnItemSelectedListener(this);
        price.setText(home.get(0).getPrice());




    }
    public  void filldata(){
        home.add(new house("1","Toronto","$220000","4 bedRoom & 2 Bathroom","house1"));
        home.add(new house("2","alberta","$560000","5 bedRoom & 4 Bathroom","house2"));
        home.add(new house("3","Hemilton","$6700000","6 bedRoom & 5 Bathroom, smimmini pool","house3"));
        home.add(new house("4","Missisuga","$9900000","7 bedRoom & 6 Bathroom,gym","house4"));
        home.add(new house("5","Niagra","$11111111","8 bedRoom & 7 Bathroom, football gorund","house5"));
        for (int i = 0;i<home.size();i++) {
            address.add(home.get(i).getHouseAddress());
        }



    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        price.setText(home.get(position).getPrice());
        int imgid = getResources().getIdentifier(home.get(position).getImgname(),"drawable",getPackageName());
        img.setImageResource(imgid);
        deatils = home.get(position).getDescription();
        image = home.get(position).getImgname();


    }


    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(this,MainActivity2.class);
        startActivity(intent);
    }
}